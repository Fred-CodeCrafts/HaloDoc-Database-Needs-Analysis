import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
 
 
# reading the database
data = pd.read_csv("service_appointment.csv")
x = data['service_name']

index = 0

for name in x:
    x[index] = name.replace(' ', '\n')
    index+=1
    
y = data['appointment_count']
# Bar chart with day against tip
plt.bar(x, y, 0.5)
 
plt.title("Bar Chart")
 
# Setting the X and Y labels
plt.xlabel('Appointment')
plt.ylabel('Count')

# Adding the legends
plt.show()