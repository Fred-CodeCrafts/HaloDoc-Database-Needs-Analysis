import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime as dt
 
# reading the database
data = pd.read_csv("monthly_revenue.csv")

# Scatter plot with day against tip
month = data['month']
x = [dt.datetime.strptime(m,'%Y-%m').date() for m in month]
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%Y'))
plt.gca().xaxis.set_major_locator(mdates.MonthLocator())
plt.plot(x,data['total_revenue'])
# Adding Title to the Plot
plt.title("Monthly Revenue")
 
# Setting the X and Y labels
plt.xlabel('Month')
plt.ylabel('Revenue')
 
plt.show()