import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime as dt

# data from https://allisonhorst.github.io/palmerpenguins/

data = pd.read_csv("online_offline.csv")

fig, ax = plt.subplots()

month = data['month']
x = [dt.datetime.strptime(m,'%Y-%m').date() for m in month]
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%Y'))
plt.gca().xaxis.set_major_locator(mdates.MonthLocator())

y1 = data['offline_count']
y2 = data['online_count']

plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5)
plt.bar(x, y1, 20, bottom=y2, label='Online')
plt.bar(x, y2, 20, label='Offline')


plt.yticks(np.arange(min(y1), max(y1)+2, 1.0))

ax.set_title("Number of Online vs Offline Appointments")
ax.legend(loc="upper right")
plt.xlabel('Month')
plt.ylabel('Count')

plt.show()