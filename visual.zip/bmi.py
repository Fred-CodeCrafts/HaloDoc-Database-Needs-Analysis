import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime as dt

# data from https://allisonhorst.github.io/palmerpenguins/

data = pd.read_csv("bmi.csv")

x1 = data['name']
x2 = data['bmi']
x = [0]*10

index = 0 
for i, j in zip(x1, x2):
    x[index] = ('{0}\n{1}'.format(i,j))
    index+=1
 
y = data['appointment_count']

plt.bar(x, y, 0.5)

#plt.yticks(np.arange(min(y), max(y)+1, 1.0))

plt.title("User BMI vs Appointments")
plt.xlabel('BMI')
plt.ylabel('Appointments')

plt.show()